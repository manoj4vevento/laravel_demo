-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 06, 2015 at 10:24 PM
-- Server version: 5.1.36-community-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `laravel_test`
--
CREATE DATABASE IF NOT EXISTS `laravel_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `laravel_test`;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2015_10_06_181034_create_services_table', 1),
('2015_10_06_181237_create_pets_table', 1),
('2015_10_06_194303_create_pet_service_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `pets`
--

DROP TABLE IF EXISTS `pets`;
CREATE TABLE IF NOT EXISTS `pets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pet_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `pets`
--

INSERT INTO `pets` (`id`, `pet_name`, `created_at`, `updated_at`) VALUES
(2, 'Cat', '2015-10-06 14:01:54', '2015-10-06 14:01:54'),
(3, 'Dog', '2015-10-06 14:02:01', '2015-10-06 14:02:01'),
(4, 'Pig', '2015-10-06 14:02:14', '2015-10-06 14:02:14');

-- --------------------------------------------------------

--
-- Table structure for table `pet_service`
--

DROP TABLE IF EXISTS `pet_service`;
CREATE TABLE IF NOT EXISTS `pet_service` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pet_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `service_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `pet_service`
--

INSERT INTO `pet_service` (`id`, `pet_id`, `service_id`, `created_at`, `updated_at`) VALUES
(6, 'Cat,Dog', 5, '2015-10-06 16:12:19', '2015-10-06 16:12:19'),
(7, 'Cat,Dog', 3, '2015-10-06 16:27:26', '2015-10-06 16:27:26'),
(8, 'Cat,Dog,Pig', 2, '2015-10-06 16:28:12', '2015-10-06 16:28:12');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE IF NOT EXISTS `services` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `service_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `service_name`, `created_at`, `updated_at`) VALUES
(2, 'Washing', '2015-10-06 13:34:23', '2015-10-06 13:34:23'),
(3, 'Shampooing', '2015-10-06 13:34:35', '2015-10-06 13:34:35'),
(4, 'Pedicure', '2015-10-06 13:34:43', '2015-10-06 13:34:43'),
(5, 'Manicure', '2015-10-06 13:34:51', '2015-10-06 13:34:51'),
(7, 'Shampooing', '2015-10-06 16:16:30', '2015-10-06 16:16:30');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
